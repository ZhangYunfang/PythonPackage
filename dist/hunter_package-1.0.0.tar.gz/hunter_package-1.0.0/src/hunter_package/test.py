# coding: utf-8

def function():
    print("function from src/hunter_package/test.py")