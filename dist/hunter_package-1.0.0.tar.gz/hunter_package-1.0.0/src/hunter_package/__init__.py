# coding: utf-8

def function():
    print("function from src/hunter_package/__init__.py")